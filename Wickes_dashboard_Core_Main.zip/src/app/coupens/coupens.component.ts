import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coupens',
  templateUrl: './coupens.component.html',
  styleUrls: ['./coupens.component.css']
})
export class CoupensComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
