import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coupen-list',
  templateUrl: './coupen-list.component.html',
  styleUrls: ['./coupen-list.component.css']
})
export class CoupenListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
