import { Component } from '@angular/core';

@Component({
  selector: 'app-products-level-three-two',
  templateUrl: './products-level-three-two.component.html',
  styleUrl: './products-level-three-two.component.css'
})
export class ProductsLevelThreeTwoComponent {

}
