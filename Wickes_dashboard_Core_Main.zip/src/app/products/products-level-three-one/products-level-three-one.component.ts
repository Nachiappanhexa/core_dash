import { Component } from '@angular/core';

@Component({
  selector: 'app-products-level-three-one',
  templateUrl: './products-level-three-one.component.html',
  styleUrl: './products-level-three-one.component.css'
})
export class ProductsLevelThreeOneComponent {

}
